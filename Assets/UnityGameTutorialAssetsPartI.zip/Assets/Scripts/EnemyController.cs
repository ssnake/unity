﻿using UnityEngine;
using System.Collections;

public class EnemyController : MonoBehaviour {
    public float speed;
    public GameObject explosion;
	// Use this for initialization
	void Start () {
	}

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag.Equals("Laser"))
        {
            Destroy(other.gameObject);
            Destroy(this.gameObject);
            Instantiate(explosion, this.transform.position, this.transform.rotation);
        }
    }


	// Update is called once per frame
	void Update () {
        this.transform.position -= new Vector3(speed, 0, 0) * Time.deltaTime;

        if (this.transform.position.x <= -10.0f)
        {
            GameOver();
        }
	}

    void GameOver()
    {
        Application.LoadLevel(1);
    }
}
