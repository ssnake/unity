﻿using UnityEngine;
using System.Collections;

public class LaserController : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        this.transform.position += new Vector3(10, 0, 0) * Time.deltaTime;

        if (this.transform.position.x > 20.0f)
        {
            Destroy(this.gameObject);
        }
	}
}
